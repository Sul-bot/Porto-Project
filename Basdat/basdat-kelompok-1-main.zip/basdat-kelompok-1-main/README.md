<img width="369" alt="Screenshot 2023-12-14 234829" src="https://github.com/SindiAprilianti29/basdat-kelompok-1/assets/118610798/630a406a-6b9d-4ecb-a8a6-3afce777df24">
<img width="942" alt="Screenshot 2023-12-14 231720" src="https://github.com/SindiAprilianti29/basdat-kelompok-1/assets/118610798/a9979d38-4a8e-44e9-bd4a-993c974595c5">
<img width="942" alt="Screenshot 2023-12-14 231444" src="https://github.com/SindiAprilianti29/basdat-kelompok-1/assets/118610798/3c280bd4-500c-412b-96dd-c82580960fcd">
<img width="959" alt="Screenshot 2023-12-14 231021" src="https://github.com/SindiAprilianti29/basdat-kelompok-1/assets/118610798/a63f004d-cdf0-4188-a204-334b882cdd8d">
<img width="944" alt="Screenshot 2023-12-14 231346" src="https://github.com/SindiAprilianti29/basdat-kelompok-1/assets/118610798/1f416d9f-6be9-4ac8-9059-455f9684415c">
<img width="960" alt="Screenshot 2023-12-14 221823" src="https://github.com/SindiAprilianti29/basdat-kelompok-1/assets/118610798/a871a8c4-d3ae-4286-898a-3a541f8d6915">
